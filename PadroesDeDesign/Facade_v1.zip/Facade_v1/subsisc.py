class SubSystemClassC:
    @staticmethod
    def method():
        return "C"