class SubSystemClassD:
    @staticmethod
    def method():
        return "D"